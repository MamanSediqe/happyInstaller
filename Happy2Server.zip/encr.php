<!DOCTYPE html>
<html>

<head>
    <title>Encryption/Decryption Test</title>
</head>

<body>
    <h2>Encryption/Decryption Test</h2>
    <form method="post">
        <label for="inputText">Input Text:</label><br>
        <input type="text" id="inputText" name="inputText" value="<?php echo isset($_POST['inputText']) ? htmlspecialchars($_POST['inputText']) : ''; ?>"><br><br>

        <label for="passKey">Pass Key:</label><br>
        <input type="text" id="passKey" name="passKey" value="<?php echo isset($_POST['passKey']) ? htmlspecialchars($_POST['passKey']) : ''; ?>"><br><br>

        <label for="recordId">Record ID:</label><br>
        <input type="text" id="recordId" name="recordId" value="<?php echo isset($_POST['recordId']) ? htmlspecialchars($_POST['recordId']) : ''; ?>"><br><br>

        <input type="submit" name="action" value="Encrypt">
        <input type="submit" name="action" value="Decrypt"><br><br>
    </form>

    <?php
    class EncryptionHelper
    {
        private static $iv = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"; // 16-byte IV

        private static function process($data, $key, $iv, $encrypt)
        {
            $result = '';
            $dataLen = strlen($data);
            $keyLen = strlen($key);
            $ivLen = strlen($iv);

            for ($i = 0; $i < $dataLen; $i++) {
                $result .= chr(ord($data[$i]) ^ ord($key[$i % $keyLen]) ^ ord($iv[$i % $ivLen]));
            }

            return $result;
        }

        private static function fixKey($passKey)
        {
            if (strlen($passKey) > 32) {
                $passKey = substr($passKey, 0, 32);
            }
            while (strlen($passKey) < 32) {
                $passKey .= 'p'; // Padding with 'p' to make the key length 32
            }
            return $passKey;
        }

        public static function encryptMessageWithPass($message, $passKey)
        {
            $key = self::fixKey($passKey);
            $encryptedBytes = self::process($message, $key, self::$iv, true);
            return base64_encode($encryptedBytes);
        }

        public static function decryptMessageWithPass($encryptedMessage, $passKey)
        {
            $key = self::fixKey($passKey);
            try {
                $encryptedBytes = base64_decode($encryptedMessage);
                $decryptedBytes = self::process($encryptedBytes, $key, self::$iv, false);
                return $decryptedBytes;
            } catch (Exception $e) {
                return "";
            }
        }
    }

    function saveToJsonFile($data, $filename = 'data.json')
    {
        if (file_exists($filename)) {
            $json_data = json_decode(file_get_contents($filename), true);
            if ($json_data === null) {
                echo "Error reading existing JSON data.<br>";
                return false;
            }
        } else {
            $json_data = [];
        }

        $json_data[] = $data;

        if (file_put_contents($filename, json_encode($json_data, JSON_PRETTY_PRINT)) === false) {
            echo "Error writing to JSON file.<br>";
            return false;
        }

        return true;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $inputText = $_POST['inputText'];
        $passKey = $_POST['passKey'];
        $recordId = $_POST['recordId'];
        $action = $_POST['action'];

        if ($action == "Encrypt") {
            $encryptedText = EncryptionHelper::encryptMessageWithPass($inputText, $passKey);
            $data = [
                'id' => $recordId,
                'encryptedText' => $encryptedText
            ];

            if (saveToJsonFile($data)) {
                echo "Encrypted Text: <textarea rows='4' cols='50'>" . htmlspecialchars($encryptedText) . "</textarea><br><br>";
                echo "Data saved successfully.<br>";
            } else {
                echo "Failed to save data.<br>";
            }
        } elseif ($action == "Decrypt") {
            $decryptedText = EncryptionHelper::decryptMessageWithPass($inputText, $passKey);
            echo "Decrypted Text: <textarea rows='4' cols='50'>" . htmlspecialchars($decryptedText) . "</textarea><br><br>";
        }
        if ($action == "Encrypt") {
            $encryptedText = EncryptionHelper::encryptMessageWithPass($inputText, $passKey);
            echo "Encrypted Text: <textarea rows='4' cols='50'>" . htmlspecialchars($encryptedText) . "</textarea><br><br>";
        } elseif ($action == "Decrypt") {
            $decryptedText = EncryptionHelper::decryptMessageWithPass($inputText, $passKey);
            echo "Decrypted Text: <textarea rows='4' cols='50'>" . htmlspecialchars($decryptedText) . "</textarea><br><br>";
        }
    }
    ?>
</body>

</html>